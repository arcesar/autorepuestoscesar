<?php  
	$destinatario = 'autorepuestoscesar2020@gmail.com';

	$nombre = $_POST['nombre'];
	$email = $_POST['email'];
	$asunto = $_POST['asunto'];
	$mensaje = $_POST['mensaje'];

	$header = "enviado desde la pagina web";
	$mensajeCompleto = $mensaje . "\n Antentamente: " . $nombre;

	mail($destinatario, $asunto, $mensajeCopleto, $header);
	echo "<script>alert('correo enviado correctamente')</script>";
	echo "<script>setTimeout(\"location.href='index.html'\",1000)</script>";

?>
