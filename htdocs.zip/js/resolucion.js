if ( screen.width >= 1024 )
{
	//Aqui cargara una hoja de estilos para las resoluciones mayores a 1024
document.write('<link rel="stylesheet" type="text/css" href="css/mayor1024.css" />'); 
}
else if ( screen.width >= 400 )
{
	//Aqui cargara una hoja de estilos para las resoluciones menores a 1024
document.write('<link rel="stylesheet" type="text/css" href="css/mayor400.css" />'); 
}
else if ( screen.width <= 400)
{
	//Aqui cargara una hoja de estilos para las resoluciones menores a 1024
document.write('<link rel="stylesheet" type="text/css" href="css/menor400.css" />'); 
}